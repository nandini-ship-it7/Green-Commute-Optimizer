const express = require('express');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');
const cors = require('cors');
const { initDatabase } = require('./db');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const INIT_SQL = fs.readFileSync(path.join(__dirname, 'init.sql'), 'utf8');
const db = initDatabase(INIT_SQL);

// API routes must come BEFORE static file serving
app.get('/api/commutes', (req, res) => {
  const rows = db.prepare('SELECT c.*, m.key AS mode_key, m.label AS mode_label FROM commutes c LEFT JOIN modes m ON m.id = c.mode_id ORDER BY date DESC').all();
  res.json(rows);
});

app.post('/api/commutes', (req, res) => {
  const { date, distance_km, mode_key, route_id, notes, user_id, latitude, longitude } = req.body;
  const uid = user_id || 1;
  const mode = db.prepare('SELECT id, factor FROM modes WHERE key = ?').get(mode_key);
  if (!mode) return res.status(400).json({ error: 'Unknown mode' });
  const emissions = Number((distance_km * mode.factor).toFixed(4));
  
  // Check if location columns exist, if not we'll handle gracefully
  try {
    const info = db.prepare('INSERT INTO commutes(user_id,date,distance_km,mode_id,emissions_kg,route_id,notes,latitude,longitude) VALUES (?,?,?,?,?,?,?,?,?)').run(
      uid, date, distance_km, mode.id, emissions, route_id || null, notes || null, latitude || null, longitude || null
    );
    const inserted = db.prepare('SELECT c.*, m.key AS mode_key FROM commutes c LEFT JOIN modes m ON m.id = c.mode_id WHERE c.id = ?').get(info.lastInsertRowid);
    res.json(inserted);
  } catch (e) {
    // If location columns don't exist, insert without them
    if (e.message.includes('no such column')) {
      const info = db.prepare('INSERT INTO commutes(user_id,date,distance_km,mode_id,emissions_kg,route_id,notes) VALUES (?,?,?,?,?,?,?)').run(
        uid, date, distance_km, mode.id, emissions, route_id || null, notes || null
      );
      const inserted = db.prepare('SELECT c.*, m.key AS mode_key FROM commutes c LEFT JOIN modes m ON m.id = c.mode_id WHERE c.id = ?').get(info.lastInsertRowid);
      res.json(inserted);
    } else {
      res.status(500).json({ error: e.message });
    }
  }
});

app.get('/api/commutes/:id', (req, res) => {
  const id = req.params.id;
  const row = db.prepare('SELECT c.*, m.key AS mode_key, m.label AS mode_label FROM commutes c LEFT JOIN modes m ON m.id = c.mode_id WHERE c.id = ?').get(id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  res.json(row);
});

app.get('/api/route/:id', (req, res) => {
  const id = req.params.id;
  const row = db.prepare('SELECT geojson FROM routes WHERE id = ?').get(id);
  if (!row) return res.status(404).json({ error: 'No route' });
  try {
    const geo = JSON.parse(row.geojson);
    res.json(geo);
  } catch (e) {
    res.json({ type: 'Feature', geometry: null });
  }
});

app.get('/api/analytics/trends', (req, res) => {
  const rows = db.prepare(`
    SELECT strftime('%Y-%m', date) as month, ROUND(SUM(emissions_kg),4) as total_co2
    FROM commutes
    GROUP BY month
    ORDER BY month ASC
  `).all();
  res.json(rows);
});

app.get('/api/analytics/mode-share', (req, res) => {
  const rows = db.prepare(`
    SELECT m.label, COUNT(c.id) AS cnt, ROUND(100.0*COUNT(c.id)/(SELECT COUNT(*) FROM commutes),2) as pct
    FROM commutes c JOIN modes m ON m.id = c.mode_id
    GROUP BY m.label ORDER BY cnt DESC
  `).all();
  res.json(rows);
});

app.get('/api/analytics/summary', (req, res) => {
  const total = db.prepare('SELECT ROUND(SUM(emissions_kg),4) as total_co2 FROM commutes').get();
  const count = db.prepare('SELECT COUNT(*) as cnt FROM commutes').get();
  res.json({ total_co2: total.total_co2 || 0, total_commutes: count.cnt || 0 });
});

app.get('/api/analytics/weekly', (req, res) => {
  const rows = db.prepare(`
    SELECT strftime('%Y-%W', date) as week, 
           ROUND(SUM(emissions_kg),4) as total_co2,
           ROUND(AVG(emissions_kg),4) as avg_co2,
           COUNT(*) as count
    FROM commutes
    GROUP BY week
    ORDER BY week DESC
    LIMIT 8
  `).all();
  res.json(rows);
});

app.get('/api/analytics/mode-emissions', (req, res) => {
  const rows = db.prepare(`
    SELECT m.label, m.key,
           ROUND(SUM(c.emissions_kg),4) as total_emissions,
           ROUND(AVG(c.emissions_kg),4) as avg_emissions,
           COUNT(c.id) AS count
    FROM commutes c JOIN modes m ON m.id = c.mode_id
    GROUP BY m.label, m.key
    ORDER BY total_emissions DESC
  `).all();
  res.json(rows);
});

app.get('/api/suggestions', (req, res) => {
  const total = db.prepare('SELECT ROUND(SUM(emissions_kg),4) as total_co2 FROM commutes').get();
  const recent = db.prepare(`
    SELECT c.*, m.key AS mode_key, m.label AS mode_label, m.factor
    FROM commutes c LEFT JOIN modes m ON m.id = c.mode_id
    ORDER BY date DESC LIMIT 10
  `).all();
  
  const modeStats = db.prepare(`
    SELECT m.key, m.label, COUNT(c.id) as count, 
           ROUND(SUM(c.emissions_kg),4) as total_emissions
    FROM commutes c JOIN modes m ON m.id = c.mode_id
    GROUP BY m.key, m.label
  `).all();
  
  const suggestions = [];
  const totalCO2 = total.total_co2 || 0;
  
  // Check for high car usage
  const carUsage = modeStats.find(m => m.key === 'car');
  if (carUsage && carUsage.count > 0) {
    const carPct = (carUsage.count / recent.length) * 100;
    if (carPct > 50) {
      suggestions.push({
        type: 'warning',
        title: 'High Car Usage Detected',
        message: `${carPct.toFixed(0)}% of your commutes are by car. Consider using public transit or cycling for shorter trips.`,
        impact: `Switching 3 car trips to public transit could save ~${(carUsage.total_emissions * 0.67).toFixed(2)}kg CO₂ per week.`,
        action: 'Try public transit or bike for trips under 10km'
      });
    }
  }
  
  // Check for recent high emissions
  const recentAvg = recent.slice(0, 5).reduce((sum, r) => sum + (r.emissions_kg || 0), 0) / Math.min(5, recent.length);
  if (recentAvg > 5) {
    suggestions.push({
      type: 'info',
      title: 'High Recent Emissions',
      message: `Your average emissions per commute is ${recentAvg.toFixed(2)}kg CO₂.`,
      impact: 'Consider walking or cycling for distances under 5km to reduce emissions.',
      action: 'Plan routes that allow for active transportation'
    });
  }
  
  // Suggest greener alternatives
  const bikeUsage = modeStats.find(m => m.key === 'bike' || m.key === 'electric_bike');
  if (!bikeUsage || bikeUsage.count === 0) {
    suggestions.push({
      type: 'success',
      title: 'Try Cycling',
      message: 'You haven\'t logged any bike commutes yet.',
      impact: 'Cycling produces zero emissions and is great for trips under 15km.',
      action: 'Consider cycling for your next commute'
    });
  }
  
  // Weekly trend suggestion
  if (totalCO2 > 20) {
    suggestions.push({
      type: 'goal',
      title: 'Emission Reduction Goal',
      message: `You've emitted ${totalCO2.toFixed(2)}kg CO₂ total.`,
      impact: 'Aim to reduce weekly emissions by 20% by mixing in more sustainable modes.',
      action: 'Set a weekly emission target and track progress'
    });
  }
  
  res.json({ suggestions, total_co2: totalCO2, recent_count: recent.length });
});

app.get('/api/goals/weekly', (req, res) => {
  const now = new Date();
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - now.getDay());
  weekStart.setHours(0, 0, 0, 0);
  
  const weekCommutes = db.prepare(`
    SELECT c.*, m.key AS mode_key
    FROM commutes c LEFT JOIN modes m ON m.id = c.mode_id
    WHERE date >= date(?)
    ORDER BY date DESC
  `).all(weekStart.toISOString().split('T')[0]);
  
  const zeroEmissionModes = ['bike', 'walk', 'running', 'skateboard', 'electric_bike', 'scooter_electric'];
  const zeroEmission = weekCommutes.filter(c => zeroEmissionModes.includes(c.mode_key)).length;
  const distance = weekCommutes.reduce((sum, c) => sum + (c.distance_km || 0), 0);
  const co2 = weekCommutes.reduce((sum, c) => sum + (c.emissions_kg || 0), 0);
  
  res.json({
    zeroEmission: { current: zeroEmission, goal: 5, progress: Math.min(100, (zeroEmission / 5) * 100) },
    distance: { current: distance, goal: 50, progress: Math.min(100, (distance / 50) * 100) },
    co2: { current: co2, goal: 10, progress: Math.min(100, (co2 / 10) * 100) }
  });
});

app.get('/api/goals/monthly', (req, res) => {
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  
  const monthCommutes = db.prepare(`
    SELECT c.*, m.key AS mode_key
    FROM commutes c LEFT JOIN modes m ON m.id = c.mode_id
    WHERE date >= date(?)
    ORDER BY date DESC
  `).all(monthStart.toISOString().split('T')[0]);
  
  const zeroEmissionModes = ['bike', 'walk', 'running', 'skateboard', 'electric_bike', 'scooter_electric'];
  const zeroEmission = monthCommutes.filter(c => zeroEmissionModes.includes(c.mode_key)).length;
  const distance = monthCommutes.reduce((sum, c) => sum + (c.distance_km || 0), 0);
  const co2 = monthCommutes.reduce((sum, c) => sum + (c.emissions_kg || 0), 0);
  
  res.json({
    zeroEmission: { current: zeroEmission, goal: 20, progress: Math.min(100, (zeroEmission / 20) * 100) },
    distance: { current: distance, goal: 200, progress: Math.min(100, (distance / 200) * 100) },
    co2: { current: co2, goal: 50, progress: Math.min(100, (co2 / 50) * 100) }
  });
});

app.get('/api/comparison', (req, res) => {
  const total = db.prepare('SELECT ROUND(SUM(emissions_kg),4) as total_co2 FROM commutes').get();
  const avgUserCO2 = 25.5; // Mock average - in production, calculate from all users
  const userCO2 = total.total_co2 || 0;
  
  res.json({
    userCO2: userCO2,
    avgUserCO2: avgUserCO2,
    comparison: userCO2 < avgUserCO2 ? 'better' : userCO2 > avgUserCO2 ? 'worse' : 'equal',
    percentage: avgUserCO2 > 0 ? ((userCO2 / avgUserCO2) * 100).toFixed(1) : 0
  });
});

// Serve frontend static files AFTER API routes
const FRONTEND_ROOT = path.join(__dirname, '..');
app.use('/', express.static(FRONTEND_ROOT));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log('Backend running on port', PORT);
});