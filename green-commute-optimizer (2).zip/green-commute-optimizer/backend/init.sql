PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS modes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key TEXT NOT NULL UNIQUE,
  label TEXT NOT NULL,
  factor REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  email TEXT UNIQUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS routes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  name TEXT,
  geojson TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS commutes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  date DATE NOT NULL,
  distance_km REAL NOT NULL,
  mode_id INTEGER NOT NULL,
  emissions_kg REAL NOT NULL,
  route_id INTEGER,
  notes TEXT,
  latitude REAL,
  longitude REAL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(mode_id) REFERENCES modes(id),
  FOREIGN KEY(route_id) REFERENCES routes(id)
);

CREATE TABLE IF NOT EXISTS milestones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  key TEXT,
  value TEXT,
  achieved_at DATETIME,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_commutes_date ON commutes(date);
CREATE INDEX IF NOT EXISTS idx_commutes_mode ON commutes(mode_id);

INSERT OR IGNORE INTO modes(key,label,factor) VALUES
('car','Car',0.18),
('electric_car','Electric Car',0.05),
('hybrid_car','Hybrid Car',0.10),
('motorbike','Motorbike',0.09),
('scooter_electric','Electric Scooter',0.01),
('electric_bike','Electric Bike',0.01),
('bike','Bicycle',0.00),
('train','Train',0.04),
('bus','Bus',0.06),
('public_transit','Public Transit',0.06),
('carpool','Carpool',0.09),
('walk','Walk',0.00),
('running','Running',0.00),
('skateboard','Skateboard',0.00);

INSERT OR IGNORE INTO users(id,name,email) VALUES (1,'Demo User','demo@example.com');

INSERT OR IGNORE INTO routes(id,user_id,name,geojson) VALUES (1,1,'Sample route', '{
  ""type"": ""Feature"",
  ""geometry"": { ""type"": ""LineString"", ""coordinates"": [[-122.4194,37.7749], [-122.4184,37.7760], [-122.4165,37.7770]] },
  ""properties"": { ""name"": ""Sample route"" }
}');

INSERT OR IGNORE INTO commutes(id,user_id,date,distance_km,mode_id,emissions_kg,route_id,notes) VALUES
(1,1,'2025-11-18',99, (SELECT id FROM modes WHERE key='electric_bike'), (99 * (SELECT factor FROM modes WHERE key='electric_bike')), 1, 'Sample long ride');