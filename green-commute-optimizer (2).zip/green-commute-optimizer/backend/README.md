# Backend
Run `npm install` then `node server.js`