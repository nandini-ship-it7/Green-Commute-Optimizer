const path = require('path');
const Database = require('better-sqlite3');
const fs = require('fs');

const DB_FILE = path.join(__dirname, 'data', 'gco.db');

function initDatabase(initSqlText) {
  const exists = fs.existsSync(DB_FILE);
  const db = new Database(DB_FILE);
  if (!exists) {
    db.exec(initSqlText);
  } else {
    // Migration: Add location columns if they don't exist
    try {
      db.prepare('SELECT latitude FROM commutes LIMIT 1').get();
    } catch (e) {
      if (e.message.includes('no such column')) {
        console.log('Migrating database: Adding location columns...');
        db.exec('ALTER TABLE commutes ADD COLUMN latitude REAL');
        db.exec('ALTER TABLE commutes ADD COLUMN longitude REAL');
        console.log('Migration complete: Location columns added');
      }
    }
    
    // Migration: Add new transportation modes if they don't exist
    const newModes = [
      ['electric_car', 'Electric Car', 0.05],
      ['hybrid_car', 'Hybrid Car', 0.10],
      ['scooter_electric', 'Electric Scooter', 0.01],
      ['train', 'Train', 0.04],
      ['bus', 'Bus', 0.06],
      ['carpool', 'Carpool', 0.09],
      ['running', 'Running', 0.00],
      ['skateboard', 'Skateboard', 0.00]
    ];
    
    newModes.forEach(([key, label, factor]) => {
      try {
        const existing = db.prepare('SELECT id FROM modes WHERE key = ?').get(key);
        if (!existing) {
          db.prepare('INSERT INTO modes(key, label, factor) VALUES (?, ?, ?)').run(key, label, factor);
          console.log(`Added new mode: ${label}`);
        }
      } catch (e) {
        // Mode might already exist, ignore
      }
    });
  }
  return db;
}

module.exports = { DB_FILE, initDatabase };