
const STORAGE_KEY = 'gco_history_v1';

async function loadHistory(){
  try{
    const res = await fetch('/api/commutes');
    if(res.ok){ const rows = await res.json(); return rows.map(r=>({date:r.date,distance:r.distance_km,mode:r.mode_key,emissions:r.emissions_kg})); }
  }catch(e){}
  try{const raw = localStorage.getItem(STORAGE_KEY); return raw?JSON.parse(raw):[]}catch(e){return[]}
}

function saveHistory(h){ localStorage.setItem(STORAGE_KEY, JSON.stringify(h)); }

async function postCommute(entry){ try{ const res = await fetch('/api/commutes',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(entry)}); if(res.ok) return await res.json(); }catch(e){} return null; }

function formatMode(m){ 
  const modeMap = {
    car: 'Car', electric_car: 'Electric Car', hybrid_car: 'Hybrid Car',
    motorbike: 'Motorbike', scooter_electric: 'Electric Scooter',
    electric_bike: 'Electric Bike', bike: 'Bicycle',
    train: 'Train', bus: 'Bus', public_transit: 'Public Transit',
    carpool: 'Carpool', walk: 'Walk', running: 'Running', skateboard: 'Skateboard'
  };
  return modeMap[m] || m.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
}
function calcEmissions(mode, distance){ 
  const FACTORS = { 
    car:0.18, electric_car:0.05, hybrid_car:0.10, motorbike:0.09, carpool:0.09,
    train:0.04, bus:0.06, public_transit:0.06,
    scooter_electric:0.01, electric_bike:0.01, bike:0, walk:0, running:0, skateboard:0
  }; 
  const f = FACTORS[mode]||0.18; 
  return f*distance; 
}

async function addEntry(entry){
  try{
    const posted = await postCommute({date:entry.date,distance_km:entry.distance,mode_key:entry.mode,route_id:entry.route_id||null,notes:entry.notes||null});
    if(posted){ const h = await loadHistory(); saveHistory(h); return h; }
  }catch(e){}
  const h = loadHistorySync(); h.unshift(entry); saveHistory(h); return h;
}

function loadHistorySync(){ try{const raw = localStorage.getItem(STORAGE_KEY); return raw?JSON.parse(raw):[]}catch(e){return[]} }

async function renderHistory(){
  const history = await loadHistory();
  const tbody = document.querySelector('#historyTable tbody');
  if(tbody){
    tbody.innerHTML = history.map((r,i)=>`<tr><td>${i+1}</td><td>${r.date}</td><td>${r.distance}</td><td>${formatMode(r.mode)}</td><td>${(r.emissions||0).toFixed? (r.emissions||0).toFixed(2) : r.emissions}</td></tr>`).join('') || '<tr><td colspan="5" style="color:var(--muted)">No data</td></tr>';
  }
  // recent list on dashboard
  const recent = document.getElementById('recentList');
  if(recent){
    recent.innerHTML = (history.slice(0,5).map(r=>`<div style="padding:12px 0;border-bottom:1px solid #f6faf6">${r.date} — ${r.distance}km — ${formatMode(r.mode)} — ${(r.emissions||0).toFixed(2)}kg</div>`).join('')) || '<div style="color:var(--muted)">No entries yet</div>';
  }
}

document.addEventListener('DOMContentLoaded', ()=>{ renderHistory(); });
